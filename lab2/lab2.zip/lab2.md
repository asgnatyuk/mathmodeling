---
## Front matter
lang: ru-Ru 
title: "Лабораторная работа №2"
subtitle: "Задача о погоне"
author: "Гнатюк Анастасия Станиславовна"

# Formatting
toc-title: "Содержание"
toc: true # Table of contents
toc_depth: 2
fontsize: 12pt
linestretch: 1.5
papersize: a4paper
documentclass: scrreprt
polyglossia-lang: russian
polyglossia-otherlangs: english
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase
indent: true
pdf-engine: lualatex
header-includes:
  - \linepenalty=10 # the penalty added to the badness of each line within a paragraph (no associated penalty node) Increasing the value makes tex try to have fewer lines in the paragraph.
  - \interlinepenalty=0 # value of the penalty (node) added after each line of a paragraph.
  - \hyphenpenalty=50 # the penalty for line breaking at an automatically inserted hyphen
  - \exhyphenpenalty=50 # the penalty for line breaking at an explicit hyphen
  - \binoppenalty=700 # the penalty for breaking a line at a binary operator
  - \relpenalty=500 # the penalty for breaking a line at a relation
  - \clubpenalty=150 # extra penalty for breaking after first line of a paragraph
  - \widowpenalty=150 # extra penalty for breaking before last line of a paragraph
  - \displaywidowpenalty=50 # extra penalty for breaking before last line before a display math
  - \brokenpenalty=100 # extra penalty for page breaking after a hyphenated line
  - \predisplaypenalty=10000 # penalty for breaking before a display
  - \postdisplaypenalty=0 # penalty for breaking after a display
  - \floatingpenalty = 20000 # penalty for splitting an insertion (can only be split footnote in standard LaTeX)
  - \raggedbottom # or \flushbottom
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Решить задачу о погоне.

# Теоретическое введение

![Рис.1: Теория](screens/5.jpg)
<p>

![Рис.1.2: Теория](screens/6.jpg)
<p>

![Рис.1.3: Теория](screens/7.jpg)
<p>

![Рис.1.4: Теория](screens/8.jpg)

# Выполнение лабораторной работы

## 1. Условие 

<p> По формуле у меня вышло число 15. 
<p> Задача №15.

<p> На море в тумане катер береговой охраны преследует лодку браконьеров.
Через определенный промежуток времени туман рассеивается, и лодка
обнаруживается на расстоянии 8,1 км от катера. Затем лодка снова скрывается втумане и уходит прямолинейно в неизвестном направлении. Известно, что скоростькатера в 3,2 раза больше скорости браконьерской лодки.

<p> 1. Запишите уравнение, описывающее движение катера, с начальными
условиями для двух случаев (в зависимости от расположения катера
относительно лодки в начальный момент времени). 

![Рис.2: Моё решение](screens/2.jpg)
<p>

![Рис.3: Код(1)](screens/3.jpg)
<p>

![Рис.4: Код(2)](screens/4.jpg)

<p> 2. Постройте траекторию движения катера и лодки для двух случаев.

<p> Первый случай:

![Рис.5: Первый случай(x - k)](screens/4.png)

<p> Второй случай:

![Рис.6: Второй случай(x + k)](screens/5.png)

<p> 3. Найдите точку пересечения траектории катера и лодки.

Для первого случая это $183^\circ$ и 6.
Для второго - $269^\circ$ и 5.

Чтобы не было грустно - посмотри на котика.

<p>

![Рис.7: Милый котик](screens/1.jpg)


# Вывод
<p> Мы решили задачу о погоне.



