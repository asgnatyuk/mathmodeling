---
## Front matter
lang: ru-RU
title: Лабораторная работа №3
author: Гнатюк Анастасия Станиславовна
institute: RUDN University, Moscow, Russian Federation
date: the 24th of february 2024

## Formatting
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
 - '\usepackage{amsmath}'
aspectratio: 43
section-titles: true
---

# Цель работы

Построить модель боевых действий через графики функций.

# Выполнение работы

![Рис.1: Условия задачи](screens/10.png)

<p>

![Рис.2: Условия задачи](screens/11.png)

<p> Распишем наше решение в виде кода на julia в блокноте. Делаем всё то же самое, как и в теоритической части, просто меняя параметры на свои.

<p>

![Рис.3: Код на julia](screens/9.png)

<p> Обзательно прописываем вывод в виде создания двух изображений с графиками функций.

<p> 1-й случай:

![Рис.3: График функций для 1-ого случая](screens/lab03_1.png)

<p>

<p> 2-й случай:

![Рис.4: График функций для 2-ого случая](screens/lab03_2.png)

<p>

# Вывод

<p> Мы построили модель боевых действий через графики функций.

